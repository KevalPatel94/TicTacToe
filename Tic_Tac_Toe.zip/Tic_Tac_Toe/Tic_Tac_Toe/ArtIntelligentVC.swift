//
//  ArtIntelligentVC.swift
//  Tic_Tac_Toe
//
//  Created by Keval Patel on 12/24/17.
//  Copyright © 2017 Keval Patel. All rights reserved.
//

import UIKit
//user = 0
//AI = 1
class ArtIntelligentVC: UIViewController {

    @IBOutlet weak var collectTicTac: UICollectionView!
    @IBOutlet weak var lblAI: UILabel!
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var lblDraw: UILabel!
    var defenseDict = [String:Array<Int>]();
    var attackDict = [String:Array<Int>]();

    var mainArray = [Int]();
    var userTag:Int = 0;
    var aiTag:Int = 0;
    var currentAttackCount: Int = 0;
    var finalAttackCount:Int = 1;
    var stepCount:Int = 0;
    var finalWinner:Int = 2;
    var userCount:Int = 0;
    var aiCount:Int = 0;
    var drawCount:Int = 0;
    var lastAIMove: Int = 0;
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        collectTicTac.delegate = self;
        collectTicTac.dataSource = self;
        
        defenseDict = ["0":[1,3,4],"1":[3],"2":[2,3],"3":[1],"6":[1]];
        attackDict = ["0":[1,3,4],"1":[3],"2":[2,3],"3":[1],"6":[1]];

        let defaults = UserDefaults.standard
        defaults.setValue(defenseDict, forKey: "AIDefense")
        defaults.setValue(defenseDict, forKey: "AIAttack")
        defaults.setValue(defenseDict, forKey: "AICheckWinner")

        mainArray = [2,2,2,2,2,2,2,2,2];
        
        lblAI.text = "0"
        lblDraw.text = "0"
        lblUser.text = "0"
        //startNewGame()


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func artficialResponse(){
        stepCount += 1
        if aiTag == 0{
                if aiTag == 0
                {
                    for index in 0...8
                    {
                        artificialIntelligence(index:index,type:"AIDefense")
                    }
                }
            
            if aiTag == 0
            {
                for index in 0...8
                {
                    artificialIntelligence(index:index,type:"AIAttack")
                }
            }
            
            if aiTag == 0
            {
                if mainArray[4] == 2
                {
                    lastAIMove = 4
                    mainArray[4] = 1;
                }
                else {
                    for index in 0...8
                    {
                        if mainArray[index] == 2
                        {
                            mainArray[index] = 1;
                            lastAIMove = index
                            break;
                        }
                    }
                }
                aiTag = 1;
            }
        }
        userTag = 0;
        animatedMove()


        
        if stepCount >= 5
        {
            checkWinner()
        }
        if finalWinner < 2
        {
            declareWinner(finalwinner: finalWinner)
        }
        if finalWinner == 2 && stepCount == 9
        {
            finalWinner = 3
            declareWinner(finalwinner: finalWinner)
        }
    }
    func artificialIntelligence(index:Int,type:String){
        print(index);
       
        
        /* -----User Default------ */
        let defaults1 = UserDefaults.standard
        print(defaults1.object(forKey: type)!)
        
        /* -----Dictionary from User Default------ */
        let tempDict = defaults1.object(forKey: type) as? [String:Array<Int>];
        
        /* -----Array from Dictionary------ */
        //var tempArray : Array<Int> = [];
        if let tempArray = tempDict!["\(index)"]
        {
            print("tempArray:  \(String(describing: tempArray))");
            for i in 0...(tempArray.count) - 1 {
                if aiTag == 0 && i != 4 && i != 5 && i != 7 && i != 8 && type.isEqual("AIDefense")
                {
                    defenseMechanism(start: index, t: tempArray[i], player: 1)
                }
                if type == "AIAttack" && aiTag == 0
                {
                    attackMechanism(start: index, t: tempArray[i], player: 1)
                }
                if type == "AICheckWinner" && i != 4 && i != 5 && i != 7 && i != 8
                {
                    checkWinnerMechanism(start:index,t:tempArray[i],Player:1)
                }
            }
        }
    }
    func defenseMechanism(start:Int,t:Int,player:Int){
        print("\(mainArray[start]),\(mainArray[start+t]),\(mainArray[start+t+t])")
        if mainArray[start] == mainArray[start+t] && mainArray[start] != 2 && mainArray[start+t+t] == 2
        {
            mainArray[start+t+t] = player;
            lastAIMove = start+t+t
            aiTag = 1;
        }
        else if mainArray[start+t] == mainArray[start + t + t] && mainArray[start + t] != 2 && mainArray[start] == 2
        {
            mainArray[start] = player;
            lastAIMove = start
            aiTag = 1;
        }
        else if mainArray[start] == mainArray[start + t + t] && mainArray[start] != 2  && mainArray[start + t] == 2
        {
            mainArray[start + t] = player;
            lastAIMove = start + t
            aiTag = 1;
        }
    }
    func attackMechanism(start:Int,t:Int,player: Int){
        
        var attack_Count: Int = 0;
        var attack_Next: Int = 0;
        
        if(mainArray[start] == player && mainArray[start + t + t] == 2 || mainArray[start] == player && mainArray[start + t] == 2)
        {
            attack_Count += 1;
            if(mainArray[start + t + t] == 2)
            {
                attack_Next = start + t + t;
            }
            else
            {
                attack_Next = start + t;
            }
        }
        else if(mainArray[start + t] == player && mainArray[start] == 2 || mainArray[start + t] == player && mainArray[start + t + t] == 2)
        {
            attack_Count += 1;
            if(mainArray[start + t + t] == 2)
            {
                attack_Next = start + t + t;
                
            }
            else
            {
                attack_Next = start;
            }
        }
        else if(mainArray[start + t + t] == player && mainArray[start] == 2 || mainArray[start + t + t] == player && mainArray[start + t] == 2 )
        {
            attack_Count += 1;
            if(mainArray[start + t] == 2)
            {
                attack_Next = start + t;
            }
            else
            {
                attack_Next = start;
            }
        }
        else if(mainArray[start] == mainArray[start + t] && mainArray[start] != 2 && mainArray[start + t + t] == 2)
        {
            attack_Count += 1;
            attack_Next = start + t + t;
            
        }
        else if(mainArray[start + t + t] == mainArray[start + t] && mainArray[start + t] != 2 && mainArray[start] == 2 )
        {
            attack_Count += 1;
            attack_Next = start;
            
        }
        else if(mainArray[start + t + t] == mainArray[start] && mainArray[start] != 2 && mainArray[start + t] == 2)
        {
            attack_Count += 1;
            attack_Next = start + t;
            
        }
        
        if(attack_Count > currentAttackCount)
        {
            currentAttackCount = attack_Count;
            finalAttackCount = 0;
            aiTag = 1;
            mainArray[attack_Next] = player;
            lastAIMove = attack_Next

        }

    }
    func checkWinner(){
        for index in 0...8
        {
            artificialIntelligence(index: index, type: "AICheckWinner")
        }

    }
    func checkWinnerMechanism(start:Int,t:Int,Player:Int){
       

        if(mainArray[start + t + t] == mainArray[start] && mainArray[start + t + t] == mainArray[start + t] && mainArray[start] != 2)
        {
            finalWinner = mainArray[start];
        }
    }
    func declareWinner(finalwinner: Int)
    {
        print(finalWinner)
        var message = ""
        if finalWinner == 1
        {
            message = "AI Wins"
            aiCount += 1;
        }
        if finalwinner == 0
        {
            message = "You Win"
            userCount += 1;
        }
        if finalwinner == 3
        {
            message = "Draw"
            drawCount += 1;
        }

        let alertController = UIAlertController(title: message, message: "Game Over", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
            UIAlertAction in
            self.startNewGame()
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
        collectTicTac.allowsSelection = true

    }
    func startNewGame()
    {
        collectTicTac.allowsSelection = true
        mainArray = [2,2,2,2,2,2,2,2,2];
        collectTicTac.reloadData()
        userTag = 0;
        aiTag = 0;
        currentAttackCount = 0;
        finalAttackCount = 1;
        stepCount = 0;
        finalWinner = 2;
        lastAIMove = 0;
        aiCount = 0;
        lblUser.text = "\(userCount)"
        lblAI.text = "\(aiCount)"
        lblDraw.text = "\(drawCount)"
        let defaults = UserDefaults.standard
        defaults.setValue(defenseDict, forKey: "AIDefense")
        defaults.setValue(defenseDict, forKey: "AIAttack")
        defaults.setValue(defenseDict, forKey: "AICheckWinner")
        sleep(3)
        
    }
    func animatedMove()  {
            let index = IndexPath(row: self.lastAIMove, section: 0)
            let cell = self.collectTicTac.cellForItem(at: index) as! ArtificialCell
            print(index)
            cell.imgViewInner.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "Image")], duration: 0)
            self.collectTicTac.allowsSelection = true
            
    }
}
extension ArtIntelligentVC: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectTicTac.dequeueReusableCell(withReuseIdentifier: "ArtificialCell", for: indexPath) as! ArtificialCell
        cell.viewInner.layer.cornerRadius = 5.0;

        return cell;
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.collectTicTac.frame.size.width - 6)/3, height: (self.collectTicTac.frame.size.height - 6)/3)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        print("user tag \(userTag)")
        print("ai tag \(aiTag)")
        print("finalWinner \(finalWinner)")

DispatchQueue.main.async {
    if self.userTag == 0 && self.finalWinner == 2 && self.mainArray[indexPath.row] == 2{
        self.collectTicTac.allowsSelection = false
        let cell = self.collectTicTac.cellForItem(at: indexPath) as! ArtificialCell
        // cell.viewInner.backgroundColor = UIColor.black
        cell.imgViewInner.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "Cross")], duration: 0)
        self.mainArray[indexPath.row] = 0;
        self.userTag = 1;
        self.self.aiTag = 0;
        self.stepCount += 1
        if self.stepCount >= 5
        {
            self.checkWinner()
            if self.finalWinner < 2
            {
                self.declareWinner(finalwinner: self.finalWinner)
            }
        }
        
        if self.finalWinner == 2
        {
            self.self.artficialResponse()
        }
        print(self.stepCount)
        if self.finalWinner == 2 && self.stepCount == 10
        {
            print(self.self.stepCount)
            self.finalWinner = 3
            self.declareWinner(finalwinner: self.finalWinner)
        }
    }
        }
//    if userTag == 0 && finalWinner == 2 && mainArray[indexPath.row] == 2{
//            let cell = collectTicTac.cellForItem(at: indexPath) as! ArtificialCell
//           // cell.viewInner.backgroundColor = UIColor.black
//            cell.imgViewInner.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "Cross")], duration: 0)
//            mainArray[indexPath.row] = 0;
//            userTag = 1;
//            aiTag = 0;
//            stepCount += 1
//            if stepCount >= 5
//            {
//                checkWinner()
//                if finalWinner < 2
//                {
//                    declareWinner(finalwinner: finalWinner)
//                }
//            }
//
//            if finalWinner == 2
//            {
//                artficialResponse()
//            }
//            print(stepCount)
//            if finalWinner == 2 && stepCount == 10
//            {
//                print(stepCount)
//                finalWinner = 3
//                declareWinner(finalwinner: finalWinner)
//            }
//        }

    }
}
