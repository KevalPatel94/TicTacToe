//
//  ArtificialCell.swift
//  Tic_Tac_Toe
//
//  Created by Keval Patel on 12/23/17.
//  Copyright © 2017 Keval Patel. All rights reserved.
//

import UIKit

class ArtificialCell: UICollectionViewCell {
    
    @IBOutlet weak var viewInner: UIView!
    @IBOutlet weak var imgViewInner: UIImageView!
    
}
