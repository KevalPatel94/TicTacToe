//
//  ViewController.swift
//  Tic_Tac_Toe
//
//  Created by Keval Patel on 12/23/17.
//  Copyright © 2017 Keval Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnVsAI: UIButton!
    @IBOutlet weak var btnMultiPlayer: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
    
    // MARK: - Button Action
    @IBAction func VsAISel(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ArtIntelligentVC") as! ArtIntelligentVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func MultiPlayerSel(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "MultiPlayerVC") as! MultiPlayerVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

