//
//  MultiPlayerVC.swift
//  Tic_Tac_Toe
//
//  Created by Keval Patel on 12/23/17.
//  Copyright © 2017 Keval Patel. All rights reserved.
//

import UIKit

class MultiPlayerVC: UIViewController{
    @IBOutlet weak var lblPlayer1: UILabel!
    @IBOutlet weak var lblDraw: UILabel!
    @IBOutlet weak var lblPlayer2: UILabel!
    
    @IBOutlet weak var collectMultiPlayer: UICollectionView!
    var defenseDict = [String:Array<Int>]();
    
    var mainArray = [Int]();
    var playerTag1:Int = 0;
    var playerTag2:Int = 0;
    var finalWinner:Int = 2;
    var stepCount:Int = 0;
    var drawCount:Int = 0;
    var player1Wins:Int = 0;
    var player2Wins:Int = 0;
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        defenseDict = ["0":[1,3,4],"1":[3],"2":[2,3],"3":[1],"6":[1]];
        let defaults = UserDefaults.standard
        defaults.setValue(defenseDict, forKey: "AICheckWinner")
        
        mainArray = [2,2,2,2,2,2,2,2,2];
        collectMultiPlayer.delegate = self;
        collectMultiPlayer.dataSource = self;
        
        lblPlayer1.text = "0"
        lblPlayer2.text = "0"
        lblDraw.text = "0"

        
    }
    func checkWinner(){
        
        /* -----User Default------ */
        let defaults1 = UserDefaults.standard
        print(defaults1.object(forKey:"AICheckWinner")!)
        
        /* -----Dictionary from User Default------ */
        let tempDict = defaults1.object(forKey:"AICheckWinner") as? [String:Array<Int>];
        
        /* -----Array from Dictionary------ */
        //var tempArray : Array<Int> = [];
        for index in 0...6 {
            if let tempArray = tempDict!["\(index)"]
            {
                print("tempArray:  \(String(describing: tempArray))");
                for i in 0...(tempArray.count) - 1 {
                    if i != 4 && i != 5 && i != 7 && i != 8
                    {
                        checkWinnerMechanism(start:index,t:tempArray[i],Player:0)
                        if finalWinner == 2
                        {
                            checkWinnerMechanism(start:index,t:tempArray[i],Player:1)
                        }
                    }
                }
            }
        }
    }
    func checkWinnerMechanism(start:Int,t:Int,Player:Int){
        
        
        if(mainArray[start + t + t] == mainArray[start] && mainArray[start + t + t] == mainArray[start + t] && mainArray[start] != 2)
        {
            print(mainArray[start])
            finalWinner = mainArray[start];
            declareWinner(finalwinner: finalWinner)
        }
    }
    func declareWinner(finalwinner: Int)
    {
        print(finalWinner)
        var message = "Draw"
        if finalWinner == 0
        {
            message = "Player 1 Wins";
            player1Wins += 1;
        }
        else if finalwinner == 1
        {
            message = "Player 2 Wins";
            player2Wins += 1;
        }
        let alertController = UIAlertController(title: message, message: "Game Over", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
            UIAlertAction in
            self.startNewGame()
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
        collectMultiPlayer.isUserInteractionEnabled = false
    }
    func startNewGame()
    {
        collectMultiPlayer.isUserInteractionEnabled = true
        mainArray = [2,2,2,2,2,2,2,2,2];
        playerTag1 = 0;
        playerTag2 = 0;
        finalWinner = 2;
        stepCount = 0;
        lblPlayer1.text = "\(player2Wins)"
        lblPlayer2.text = "\(player1Wins)"
        lblDraw.text = "\(drawCount)"
        collectMultiPlayer.reloadData()

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension MultiPlayerVC: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    // MARK: - Collection View Delegate
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectMultiPlayer.dequeueReusableCell(withReuseIdentifier: "MultiPlayerCell", for: indexPath) as! MultiPlayerCell
        cell.viewInner.layer.cornerRadius = 5.0;
       // cell.viewInner.backgroundColor = UIColor.green
        return cell;
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.collectMultiPlayer.frame.size.width - 6)/3, height: (self.collectMultiPlayer.frame.size.height - 6)/3)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if stepCount >= 4 {
            checkWinner()
        }
        if finalWinner == 2 && mainArray[indexPath.row] == 2
        {
            let cell = collectMultiPlayer.cellForItem(at: indexPath) as! MultiPlayerCell
            if playerTag1 == 0 {
                mainArray[indexPath.row] = 0
                //cell.viewInner.backgroundColor = UIColor.black
                cell.imgViewInner.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "Cross")], duration: 0.5)
                playerTag1 = 1;
                stepCount += 1;
            }
            else if playerTag1 == 1 && mainArray[indexPath.row] == 2{
                mainArray[indexPath.row] = 1
                //cell.viewInner.backgroundColor = UIColor.cyan
                cell.imgViewInner.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "Image")], duration: 0.5)
                playerTag1 = 0;
                stepCount += 1;
            }
            if stepCount >= 4 {
                checkWinner()
            }
            if stepCount == 9 && finalWinner == 2
            {
                drawCount += 1;
                declareWinner(finalwinner: 3)
            }
        }
    }
}

