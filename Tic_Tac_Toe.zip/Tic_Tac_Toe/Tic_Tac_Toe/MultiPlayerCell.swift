//
//  MultiPlayerCell.swift
//  Tic_Tac_Toe
//
//  Created by Keval Patel on 12/25/17.
//  Copyright © 2017 Keval Patel. All rights reserved.
//

import UIKit

class MultiPlayerCell: UICollectionViewCell {
    @IBOutlet weak var viewInner: UIView!
    @IBOutlet weak var imgViewInner: UIImageView!
}
